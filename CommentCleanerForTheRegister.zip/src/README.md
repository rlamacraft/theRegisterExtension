# theRegisterExtension
Attempt at building a Chrome Extension to make the comment section of theRegister.co.uk actually readable (and possible a few other stylistic changes)
